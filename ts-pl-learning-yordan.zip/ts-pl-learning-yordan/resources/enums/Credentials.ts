export enum Credentials {
  EMAIL = 'karamfilovs@gmail.com',
  PASSWORD = '111111',
}
