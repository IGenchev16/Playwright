export enum Currency {
  Euro = 'EUR',
  USD = 'USD',
}
